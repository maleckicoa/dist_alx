from setuptools import setup

setup(name='dist_alx',
      version='0.0',
      description='Gaussian and Binomial distributions',
      packages=['dist_alx'],
      author_email='mihajlovic.aleksa@gmail.com',
      zip_safe=False)
